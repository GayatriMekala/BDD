package pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageFactory 
{
	WebDriver driver;
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;

	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitNo;

	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expiryMonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;
	
	//using how class
		@FindBy(how=How.ID, using="btnPayment")
		@CacheLookup
		WebElement makeButton;
	
	public WebElement getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}
public WebElement getDebitNo() {
		return debitNo;
	}
	public void setDebitNo(String debitNo) {
		this.debitNo.sendKeys(debitNo);
	}
	public WebElement getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	public WebElement getExpiryMonth() {
		return expiryMonth;
	}
	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);;
	}

	
	
	/**
	 * @return the makeButton
	 */
	public WebElement getMakeButton() {
		return makeButton;
	}
	/**
	 * @param makeButton the makeButton to set
	 */
	
	
	public WebElement getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	public void setMakeButton() {
		this.makeButton.click();;
	}
	 //initiating Elements
		public PaymentPageFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	
		
}
