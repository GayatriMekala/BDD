package payment;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pagebean.PaymentPageFactory;

public class PaymentStepDefinition 
{		private WebDriver driver;
		private PaymentPageFactory PaymentPageFactory;
		

	
	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {

		PaymentPageFactory.setCardHolderName("");
		PaymentPageFactory.setMakeButton();
	
	}

	@Then("^displays 'Please fill the CardHolder Name'$")
	public void displays_Please_fill_the_CardHolder_Name() throws Throwable {
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();

		PaymentPageFactory.setCardHolderName("Yogini Naik");
		PaymentPageFactory.setDebitNo("");
		PaymentPageFactory.setMakeButton();;
	
	}

	@Then("^displays 'Please fill Debit Card Number'$")
	public void displays_Please_fill_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
@When("^user does not enter CVV value$")
public void user_does_not_enter_CVV_value() throws Throwable {

	PaymentPageFactory.setCardHolderName("Yogini Naik");
	PaymentPageFactory.setDebitNo("42342");
	PaymentPageFactory.setCvv("");
	PaymentPageFactory.setMakeButton();
	}

@Then("^displays 'Please fill CVV number'$")
public void displays_Please_fill_CVV_number() throws Throwable {
	String expectedMessage="Please fill the CVV";
	String actualMessage=driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}
	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {

		PaymentPageFactory.setCardHolderName("Yogini Naik");
		PaymentPageFactory.setDebitNo("42342");
		PaymentPageFactory.setCvv("343");
		PaymentPageFactory.setExpiryMonth("");
		PaymentPageFactory.setMakeButton();;
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
		PaymentPageFactory.setCardHolderName("Yogini Naik");
		PaymentPageFactory.setDebitNo("42342");
		PaymentPageFactory.setCvv("343");
		PaymentPageFactory.setExpiryMonth("3");
		PaymentPageFactory.setYear("");
	PaymentPageFactory.setMakeButton();
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year() throws Throwable {
		String expectedMessage="Please fill the expiration year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
	}

}
