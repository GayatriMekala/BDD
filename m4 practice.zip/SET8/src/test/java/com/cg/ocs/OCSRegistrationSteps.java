package com.cg.ocs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.factory.OCSFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class OCSRegistrationSteps {
	
	private WebDriver driver;
	private OCSFactory ocsFactory;
	private String title;
	boolean present=false;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sasathi\\eclipse-workspace\\workspace\\185937_SET8\\Drivers\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^User is on the 'Registration' Page$")
	public void user_is_on_the_Registration_Page() {
		driver.get("C:\\Users\\sasathi\\eclipse-workspace\\workspace\\185937_SET8\\Recipe_class_registration.html");
		
		ocsFactory=new OCSFactory(driver);
	}

	@When("^Title of the Registartion Page is 'Online Cooking Class Enquiry Form'$")
	public void title_of_the_Registartion_Page_is_Online_Cooking_Class_Enquiry_Form() throws InterruptedException {
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(10000);
		title=driver.getTitle();
		
	}

	@Then("^Dispaly 'Title Matched'$")
	public void dispaly_Title_Matched() {
		Assert.assertEquals("Online Cooking Class Enquiry Form", title);
		System.out.println("Title Matched");
		driver.close();
	}

	@When("^The Registration Page contains a text \"(.*?)\"$")
	public void the_Registration_Page_contains_a_text(String arg1) {
       
		present=driver.getPageSource().contains(arg1);

	}

	@Then("^Display 'The page contains the text: Online Cooking School'$")
	public void display_The_page_contains_the_text_Online_Cooking_School() {
		Assert.assertEquals(true, present);
		System.out.println("The page contains the text: Online Cooking School");
		driver.close();
	}

	@Then("^Click on 'Download our Recipe class Brochure'$")
	public void click_on_Download_our_Recipe_class_Brochure() throws InterruptedException {
		
		ocsFactory.setDownloadLink();
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Thread.sleep(15000);
		
	}

	@Given("^User is on the 'msg\\.html' page$")
	public void user_is_on_the_msg_html_page() {
		
		driver.navigate().to("C:\\Users\\sasathi\\eclipse-workspace\\workspace\\185937_SET8\\msg.html");
		
	}

	@When("^The  Page contains a text \"(.*?)\"$")
	public void the_Page_contains_a_text(String arg1) {
		
		present=driver.getPageSource().contains(arg1);	
	}

	@Then("^Display 'The page contains the text: Recipe class Brochure is sent to your registered mail id'$")
	public void display_The_page_contains_the_text_Recipe_class_Brochure_is_sent_to_your_registered_mail_id() {
		
		Assert.assertEquals(true, present);
		System.out.println("The page contains the text: Recipe class Brochure is sent to your registered mail id");
		driver.close();
	}

	@When("^User clicks on 'Go Back to Registration' link$")
	public void user_clicks_on_Go_Back_to_Registration_link() {
		
		driver.findElement(By.linkText("Go Back to Registration")).click();
		
	}

	@When("^The user is navigated back to the Registartion Page$")
	public void the_user_is_navigated_back_to_the_Registartion_Page() {
		driver.navigate().to("C:\\Users\\sasathi\\eclipse-workspace\\workspace\\185937_SET8\\Recipe_class_registration.html");
		
	}

	@Then("^Display 'User is on the Registration Page'$")
	public void display_User_is_on_the_Registration_Page() {
		
		System.out.println("User is on the Registration Page");
		driver.close();
		
	}

	@When("^User leaves the First Name empty$")
	public void user_leaves_the_First_Name_empty() {
		
		ocsFactory.setFirstName("");
		ocsFactory.setEnquireNowButton();
		
	}

	@Then("^verify the alert contains the text 'First Name must be filled out' or not$")
	public void verify_the_alert_contains_the_text_First_Name_must_be_filled_out_or_not() {
		
		String expectedMsg="First Name must be filled out";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^User leaves the Last Name empty$")
	public void user_leaves_the_Last_Name_empty() {
		
		ocsFactory.setFirstName("Charmisha");
		ocsFactory.setLastName("");
		ocsFactory.setEnquireNowButton();
		
	}

	@Then("^verify the alert contains the text 'Last Name must be filled out' or not$")
	public void verify_the_alert_contains_the_text_Last_Name_must_be_filled_out_or_not() {
		String expectedMsg="Last Name must be filled out";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();
		
		
	}

	@When("^User enters Characters in Mobile field$")
	public void user_enters_Characters_in_Mobile_field() {
		ocsFactory.setFirstName("Charmisha");
		ocsFactory.setLastName("Sathi");
		ocsFactory.setEmail("charmisha@capgemini.com");
		ocsFactory.setMobile("hgui");
		ocsFactory.setEnquireNowButton();
		
	}

	@Then("^verify the alert contains the text 'Enter numeric value' or not$")
	public void verify_the_alert_contains_the_text_Enter_numeric_value_or_not() {
		String expectedMsg="Enter numeric value";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();	
	}

	@When("^User enters incorrect mobile number$")
	public void user_enters_incorrect_mobile_number() {
		
		ocsFactory.setFirstName("Charmisha");
		ocsFactory.setLastName("Sathi");
		ocsFactory.setEmail("charmisha@capgemini.com");
		ocsFactory.setMobile("2146923");
		ocsFactory.setEnquireNowButton();
	}

	@Then("^verify the alert contains the text 'Enter (\\d+) digit Mobile number' or not$")
	public void verify_the_alert_contains_the_text_Enter_digit_Mobile_number_or_not(int arg1) {
		
		String expectedMsg="Enter 10 digit Mobile number";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();
		
		
	}

	@When("^User enters all the valid details and clicks on 'Enquire Now!!!' button$")
	public void user_enters_all_the_valid_details_and_clicks_on_Enquire_Now_button() {
		
		ocsFactory.setFirstName("Charmisha");
		ocsFactory.setLastName("Sathi");
		ocsFactory.setEmail("charmisha@capgemini.com");
		ocsFactory.setMobile("9874561234");
		ocsFactory.setCategory("Non-Veg");
		ocsFactory.setCity("Mumbai");
		ocsFactory.setModeOfLearning("In house training");
		ocsFactory.setCourseDuration("6 months");
		ocsFactory.setEnquireNowButton();
		
		
	}

	@Then("^verify the alert contains the text 'Enquiry details must be filled out' or not$")
	public void verify_the_alert_contains_the_text_Enquiry_details_must_be_filled_out_or_not() {
		
		String expectedMsg="Enquiry details must be filled out";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^User enters all the valid Enquiry details and clicks on 'Enquire Now!!!' button$")
	public void user_enters_all_the_valid_Enquiry_details_and_clicks_on_Enquire_Now_button() {
		
		ocsFactory.setFirstName("Charmisha");
		ocsFactory.setLastName("Sathi");
		ocsFactory.setEmail("charmisha@capgemini.com");
		ocsFactory.setMobile("9874561234");
		ocsFactory.setCategory("Non-Veg");
		ocsFactory.setCity("Mumbai");
		ocsFactory.setModeOfLearning("In house training");
		ocsFactory.setCourseDuration("6 months");
		ocsFactory.setYourEnquiry("How much would be the fee?");
		ocsFactory.setEnquireNowButton();
		
	}

	@Then("^verify the alert contains the text 'Thank you for submitting the online recipe class Enquiry' or not$")
	public void verify_the_alert_contains_the_text_Thank_you_for_submitting_the_online_recipe_class_Enquiry_or_not() {
		
		String expectedMsg="Thank you for submitting the online recipe class Enquiry";
		String actualMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMsg, actualMsg);
		driver.switchTo().alert().accept();
		driver.close();
		
		
	}

	@When("^The page contains the text 'Our location representative will contact you soon'$")
	public void the_page_contains_the_text_Our_location_representative_will_contact_you_soon() {
		present=driver.getPageSource().contains("Our location representative will contact you soon");
		
		
	}

	@Then("^Display 'Successfully Registered\\.\\.\\.\\.'$")
	public void display_Successfully_Registered() {
		Assert.assertEquals(true, present);
		System.out.print("Successfully Registered....");
		driver.close();
	}


	
	

}
