package vehicle;
import bean.vehicleFactory;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {	
	
	private WebDriver driver;
	private vehicleFactory vehicleFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
			   "chrome/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on Vehicle Registration Form$")
	public void user_is_on_Vehicle_Registration_Form()  {
		driver.get("C:\\Capgemini\\setup\\SpringMCV\\Vehicle\\WebPages-BDD MPT\\VehicleRegistrationForm.html");
		vehicleFactory = new vehicleFactory(driver);  
	}

	@Then("^check the heading of the  Vehicle Registration Form$")
	public void check_the_heading_of_the_Vehicle_Registration_Form() throws InterruptedException {
		String expected = "Vehicle Registration Form";
		String actual = vehicleFactory.getHeading();
		Assert.assertEquals(expected, actual);
		Thread.sleep(1000);
		driver.close();
	    
	}

	@When("^User does not enter Title$")
	public void user_does_not_enter_Title()  {
		vehicleFactory.setTitle("");
		vehicleFactory.setSubmit();
	}

	@Then("^Display alert box for to enter Title$")
	public void display_alert_box_for_to_enter_Title() throws InterruptedException {
		String expected = "Select title from the list";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter Owner Name$")
	public void user_does_not_enter_Owner_Name() {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("");
		vehicleFactory.setSubmit();
	    
	}

	@Then("^Display alert box for to enter Owner Name$")
	public void display_alert_box_for_to_enter_Owner_Name() throws InterruptedException{
		String expected = "Owner Name should not be empty and must contain alphabets with in the range of 5 to 20";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User does not enter Gender$")
	public void user_does_not_enter_Gender() {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		
		vehicleFactory.setSubmit();
	}

	@Then("^Display alert box for to enter Gender$")
	public void display_alert_box_for_to_enter_Gender() throws InterruptedException {
		String expected = "Please Select gender";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User does not enter Address$")
	public void user_does_not_enter_Address()  {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("");
		vehicleFactory.setSubmit(); 
	}

	@Then("^Display alert box for to enter Address$")
	public void display_alert_box_for_to_enter_Address() throws InterruptedException {
		String expected = "address should not be empty and must be alphanumeric with in the range of 5 to 20";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}

	@When("^User does not enter City$")
	public void user_does_not_enter_City()   {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("");
		vehicleFactory.setSubmit(); 
	   
	}

	@Then("^Display alert box for to enter City$")
	public void display_alert_box_for_to_enter_City() throws InterruptedException {
		String expected = "city should not be empty and must have alphabet characters only";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^User does not enter State$")
	public void user_does_not_enter_State()   {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("Chennai");
		vehicleFactory.setState("");
		
		vehicleFactory.setSubmit(); 
	   
	}

	@Then("^Display alert box for to enter State$")
	public void display_alert_box_for_to_enter_State() throws InterruptedException {
		String expected = "State should not be empty and must have alphabet characters only";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User does not enter Country$")
	public void user_does_not_enter_Country(){
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("");
		vehicleFactory.setSubmit(); 
	}

	@Then("^Display alert box for to enter Country$")
	public void display_alert_box_for_to_enter_Country() throws InterruptedException {
		String expected = "Select the country from the list";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User does not enter Zipcode$")
	public void user_does_not_enter_Zipcode() {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("India");
		vehicleFactory.setZipcode("");
		vehicleFactory.setSubmit(); 
	}

	@Then("^Display alert box for to enter Zipcode$")
	public void display_alert_box_for_to_enter_Zipcode() throws InterruptedException  {
		String expected = "ZIP code should not be empty and must have 6 numeric characters only";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	   
	}

	@When("^User does not enter VehicleType$")
	public void user_does_not_enter_VehicleType()  {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("India");
		vehicleFactory.setZipcode("123456");
		
		vehicleFactory.setSubmit(); 
	}
	    

	@Then("^Display alert box for to enter VehicleType$")
	public void display_alert_box_for_to_enter_VehicleType() throws InterruptedException   {
		String expected = "Please Select Vehicle type";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter FuelType$")
	public void user_does_not_enter_FuelType()  {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("India");
		vehicleFactory.setZipcode("123456");
		vehicleFactory.setVehicletype2wheeler();
		
		vehicleFactory.setSubmit(); 
	    
	}

	@Then("^Display alert box for to enter FuelType$")
	public void display_alert_box_for_to_enter_FuelType() throws InterruptedException  {
		String expected = "Please Select fuel type";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	   	}

	@When("^User does not enter Year of Mfg$")
	public void user_does_not_enter_Year_of_Mfg()  {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("India");
		vehicleFactory.setZipcode("123456");
		vehicleFactory.setVehicletype2wheeler();
		vehicleFactory.setFueltypeePetrol();
		vehicleFactory.setYearofMfg("");
		vehicleFactory.setSubmit(); 
	}

	@Then("^Display alert box for to enter Year of Mfg$")
	public void display_alert_box_for_to_enter_Year_of_Mfg() throws  InterruptedException {
		String expected = "Select mfg year from the list";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	   	}
	

	


	@When("^user enters valid details$")
	public void user_enters_valid_details()  {
		vehicleFactory.setTitle("Ms");
		vehicleFactory.setOwnername("Gayathri");
		vehicleFactory.setGenderFemale();
		vehicleFactory.setAddress("gunupudi");
		vehicleFactory.setCity("chennai");
		vehicleFactory.setState("Andhra");
		vehicleFactory.setCountry("India");
		vehicleFactory.setZipcode("123456");
		vehicleFactory.setVehicletype2wheeler();
		vehicleFactory.setFueltypeePetrol();
		vehicleFactory.setYearofMfg("2015");
		vehicleFactory.setSubmit(); 
	}

	@Then("^displays Successfully Completed!!!'$")
	public void displays_Successfully_Completed() throws  InterruptedException {
		String expected = "You are Succesfully registered your vehicle";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
	}
}
