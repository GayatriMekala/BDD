package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class vehicleFactory {
	
	
	WebDriver driver;
	
	//heading
	@FindBy(xpath ="/html/body/h1")
	@CacheLookup
	WebElement heading;
	
	//Title
	@FindBy(xpath = "/html/body/form/ul/li[2]/select")
	@CacheLookup
	WebElement Title;
	
	@FindBy(xpath = "//*[@id=\"ownername\"]")
	@CacheLookup
	WebElement ownername;
	
	
	@FindBy(xpath = "/html/body/form/ul/li[6]/input")
	@CacheLookup
	WebElement genderMale;
	
	@FindBy(xpath = "/html/body/form/ul/li[7]/input")
	@CacheLookup
	WebElement genderFemale;
	
	
	@FindBy(xpath = "//*[@id=\"address\"]")
	@CacheLookup
	WebElement address;
	
	@FindBy(xpath = "//*[@id=\"city\"]")
	@CacheLookup
	WebElement city;
	
	@FindBy(xpath = "//*[@id=\"state\"]")
	@CacheLookup
	WebElement state;
	
	
	@FindBy(xpath = "/html/body/form/ul/li[15]/select")
	@CacheLookup
	WebElement country;
	
	@FindBy(xpath = "//*[@id=\"zip\"]")
	@CacheLookup
	WebElement zipcode;
	
	@FindBy(xpath = "/html/body/form/ul/li[19]/input")
	@CacheLookup
	WebElement vehicletype4wheeler;
	
	@FindBy(xpath = "/html/body/form/ul/li[20]/input")
	@CacheLookup
	WebElement vehicletype2wheeler;
	
	@FindBy(xpath = "/html/body/form/ul/li[22]/input")
	@CacheLookup
	WebElement fueltypeePetrol;
	
	@FindBy(xpath = "/html/body/form/ul/li[23]/input")
	@CacheLookup
	WebElement fueltypeeDisel;
	
	
	@FindBy(xpath = "/html/body/form/ul/li[25]/select")
	@CacheLookup
	WebElement yearofMfg;
	
	@FindBy(xpath = "/html/body/form/ul/li[26]/input")
	@CacheLookup
	WebElement submit;
	
	public vehicleFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getHeading() {
		return heading.getText();
	}

	public void setHeading(String heading) {
		this.heading.sendKeys(heading);;
	}

	public WebElement getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title.sendKeys(title);
	}

	public WebElement getOwnername() {
		return ownername;
	}

	public void setOwnername(String ownername) {
		this.ownername.sendKeys(ownername);
	}
	

	public WebElement getGenderMale() {
		return genderMale;
	}

	public void setGenderMale() {
		this.genderMale.click();
	}

	public WebElement getGenderFemale() {
		return genderFemale;
	}

	public void setGenderFemale() {
		this.genderFemale.click();
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}
	

	public WebElement getVehicletype4wheeler() {
		return vehicletype4wheeler;
	}

	public void setVehicletype4wheeler() {
		this.vehicletype4wheeler.click();
	}

	public WebElement getVehicletype2wheeler() {
		return vehicletype2wheeler;
	}

	public void setVehicletype2wheeler() {
		this.vehicletype2wheeler.click();
	}
	
	

	public WebElement getFueltypeePetrol() {
		return fueltypeePetrol;
	}

	public void setFueltypeePetrol() {
		this.fueltypeePetrol.click();
	}

	public WebElement getFueltypeeDisel() {
		return fueltypeeDisel;
	}

	public void setFueltypeeDisel() {
		this.fueltypeeDisel.click();
	}

	public WebElement getYearofMfg() {
		return yearofMfg;
	}

	public void setYearofMfg(String yearofMfg) {
		this.yearofMfg.sendKeys(yearofMfg);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}
}

	