package rf;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.Factory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class setdef {
	
	private WebDriver driver;
	private Factory factory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"chrome/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on RegistrationForm page$")
	public void user_is_on_RegistrationForm_page() {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:\\Capgemini\\setup\\SpringMCV\\bhavani\\WebPages\\RegistrationForm.html");
		factory = new Factory(driver);
	    
	}
	
	@Then("^check the heading of the registration form page$")
	public void check_the_heading_of_the_registration_form_page() throws InterruptedException {
		String expected = "Registration Form";
		String actual = factory.getHeading();
		Assert.assertEquals(expected, actual);
		Thread.sleep(1000);
		driver.close();
	    
	    
	}

	@When("^User does not enter userId$")
	public void user_does_not_enter_userId() {
	    factory.setUserId("");
	    factory.setSubmit();
	}

	@Then("^Display alert box for to enter userId$")
	public void display_alert_box_for_to_enter_userId() throws InterruptedException {
		String expected = "User Id should not be empty / length be between 5 to 12";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	    
	}

	@When("^User enter Invalid userId$")
	public void user_enter_Invalid_userId() {
	   factory.setUserId("1234");
	   factory.setSubmit();
	}

	@Then("^Display alert box for to enter valid userId$")
	public void display_alert_box_for_to_enter_valid_userId() throws InterruptedException {
		String expected = "User Id should not be empty / length be between 5 to 12";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	}

	@When("^User does not enter password$")
	public void user_does_not_enter_password()  {
		factory.setUserId("123456");
		factory.setPassword("");
		factory.setSubmit();  
	}

	@Then("^Display alert box for to enter password$")
	public void display_alert_box_for_to_enter_password() throws InterruptedException {
		String expected = "Password should not be empty / length be between 7 to 12";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	}

	@When("^User enter Invalid password$")
	public void user_enter_Invalid_password() {
		factory.setUserId("123456");
		factory.setPassword("Gayi");
		factory.setSubmit();  
	}

	@Then("^Display alert box for to enter valid password$")
	public void display_alert_box_for_to_enter_valid_password() throws InterruptedException  {
		String expected = "Password should not be empty / length be between 7 to 12";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	    
	}

	@When("^User does not enter name$")
	public void user_does_not_enter_name() {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("");
		 factory.setSubmit();  
	}
	@Then("^Display alert box for to enter name$")
	public void display_alert_box_for_to_enter_name() throws InterruptedException {
		String expected = "Name should not be empty and must have alphabet characters only";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
		
	    
	}

	@When("^User enter Invalid name$")
	public void user_enter_Invalid_name()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri123");
		 factory.setSubmit();  
	}

	@Then("^Display alert box for to enter valid name$")
	public void display_alert_box_for_to_enter_valid_name() throws  InterruptedException{
		String expected = "Name should not be empty and must have alphabet characters only";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	   
	}

	@When("^User enter Invalid address$")
	public void user_enter_Invalid_address()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("");
		 factory.setSubmit();  
	}
	

	@Then("^Display alert box for to enter valid address$")
	public void display_alert_box_for_to_enter_valid_address() throws  InterruptedException {
		String expected = "User address must have alphanumeric characters only";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	    
	}

	@When("^User does not enter country$")
	public void user_does_not_enter_country()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi45");
		factory.setCountry("");
		 factory.setSubmit();    
	}

	@Then("^Display alert box for to enter country$")
	public void display_alert_box_for_to_enter_country() throws  InterruptedException {
		String expected = "Select your country from the list";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	}

	@When("^User does not enter zipcode$")
	public void user_does_not_enter_zipcode()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("");
		 factory.setSubmit();   
	    
	}

	@Then("^Display alert box for to enter zipcode$")
	public void display_alert_box_for_to_enter_zipcode() throws InterruptedException{
		String expected = "ZIP code must have numeric characters only";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	}

	@When("^User enter Invalid zipcode$")
	public void user_enter_Invalid_zipcode() {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("ABCD9999");
		 factory.setSubmit();   
	   
	}

	@Then("^Display alert box for to enter valid zipcode$")
	public void display_alert_box_for_to_enter_valid_zipcode() throws InterruptedException {
		String expected = "ZIP code must have numeric characters only";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();
	  
	}

	@When("^User does not enter email$")
	public void user_does_not_enter_email() {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("");
		 factory.setSubmit();   
	}

	@Then("^Display alert box for to enter email$")
	public void display_alert_box_for_to_enter_email() throws InterruptedException  {
		String expected = "You have entered an invalid email address!";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();   
	}

	@When("^User enter Invalid email$")
	public void user_enter_Invalid_email() {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri");
		 factory.setSubmit();   
	}

	@Then("^Display alert box for to enter valid email$")
	public void display_alert_box_for_to_enter_valid_email() throws InterruptedException{
		String expected = "You have entered an invalid email address!";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();   
	}

	@When("^User enter Invalid_com email$")
	public void user_enter_Invalid_com_email()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri@gmail");
		 factory.setSubmit();   
	 
	}

	@Then("^Display alert box for to enter valid_com email$")
	public void display_alert_box_for_to_enter_valid_com_email() throws InterruptedException {
		String expected = "You have entered an invalid email address!";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();   
	}

	@When("^User does not enter sex$")
	public void user_does_not_enter_sex() {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri@gmail.com");
	
		 factory.setSubmit();   
	 
	}

	@Then("^Display alert box for to enter sex$")
	public void display_alert_box_for_to_enter_sex() throws InterruptedException {
		String expected = "Please Select gender";
	    String actual = driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    driver.close();   
	    
	}

	@When("^user does not enter language and clicks on Registerlink$")
	public void user_does_not_enter_language_and_clicks_on_Registerlink()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri@gmail.com");
		factory.setSexMale();
		 factory.setSubmit();   
	}

	@Then("^Display alert message to enter language$")
	public void display_alert_message_to_enter_language() throws InterruptedException {
		String expected = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		Thread.sleep(2000);
		 driver.switchTo().alert().accept();
		    Thread.sleep(1000);
		driver.close();
	}

	@When("^user does not enter about and clicks on Registerlink$")
	public void user_does_not_enter_about_and_clicks_on_Registerlink()  {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri@gmail.com");
		factory.setSexMale();
		factory.setLanguage_English();
		factory.setAbout("");
		 factory.setSubmit();   
	   
	}

	@Then("^Display alert message to enter about$")
	public void display_alert_message_to_enter_about() throws InterruptedException {
		String expected = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		Thread.sleep(2000);
		 driver.switchTo().alert().accept();
		    Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		factory.setUserId("123456");
		factory.setPassword("Gayathri");
		factory.setName("gayathri");
		factory.setAddress("gunupudi15");
		factory.setCountry("Australia");
		factory.setZipCode("533449");
		factory.setEmail("gayathri@gmail.com");
		factory.setSexMale();
		factory.setLanguage_English();
		factory.setAbout("Satisfied");
		 factory.setSubmit();   
	   
	}

	@Then("^displays Successfully Completed!!!'$")
	public void displays_Successfully_Completed() throws InterruptedException {
		String expected = "Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	    
	}
	    
	}
