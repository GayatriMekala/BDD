package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Factory {
	WebDriver driver;
	
	/*@FindBy(name = "userid")
	@CacheLookup
	WebElement userId;
	@FindBy(how = How.NAME, using = "passid")
	@CacheLookup
	WebElement password;
	@FindBy(how = How.NAME, using = "username")
	@CacheLookup
	WebElement name;
	@FindBy(xpath="//*[@id=\"addr\"]")
	@CacheLookup
	WebElement address;
	@FindBy(xpath = "/html/body/form/ul/li[10]/select")
	@CacheLookup
	WebElement country;
	@FindBy(xpath = "/html/body/form/ul/li[12]/input")
	@CacheLookup
	WebElement zipCode;

	@FindBy(xpath = "/html/body/form/ul/li[14]/input")
	@CacheLookup
	WebElement email;
	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement sexMale;
	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement sexFemale;
	@FindBy(xpath = "/html/body/form/ul/li[19]/span")
	@CacheLookup
	WebElement language_English;
	@FindBy(xpath = "/html/body/form/ul/li[20]/input")
	@CacheLookup
	WebElement language_NonEnglish;
	@FindBy(xpath = "//*[@id=\"desc\"]")
	@CacheLookup
	WebElement about;
	@FindBy(xpath = "/html/body/form/ul/li[23]/input")
	@CacheLookup
	WebElement submit;
	
	public Factory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

}
*/	@FindBy(xpath ="/html/body/h1")
	@CacheLookup
	WebElement heading;

	@FindBy(name = "userid")
	@CacheLookup
	WebElement userId;
	
	@FindBy(how = How.NAME, using = "passid")
	@CacheLookup
	WebElement password;
	
	@FindBy(how = How.NAME, using = "username")
	@CacheLookup
	WebElement name;
	
	@FindBy(xpath="//*[@id=\"addr\"]")
	@CacheLookup
	WebElement address;
	@FindBy(xpath = "/html/body/form/ul/li[10]/select")
	@CacheLookup
	WebElement country;
	@FindBy(xpath = "/html/body/form/ul/li[12]/input")
	@CacheLookup
	WebElement zipCode;

	@FindBy(xpath = "/html/body/form/ul/li[14]/input")
	@CacheLookup
	WebElement email;
	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement sexMale;
	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement sexFemale;
	@FindBy(xpath = "/html/body/form/ul/li[19]/span")
	@CacheLookup
	WebElement language_English;
	@FindBy(xpath = "/html/body/form/ul/li[20]/input")
	@CacheLookup
	WebElement language_NonEnglish;
	@FindBy(xpath = "//*[@id=\"desc\"]")
	@CacheLookup
	WebElement about;
	@FindBy(xpath = "/html/body/form/ul/li[23]/input")
	@CacheLookup
	WebElement submit;
	
	public Factory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	
	
	public String getHeading() {
		return heading.getText();
	}



	public void setHeading(String heading) {
		this.heading.sendKeys(heading);;
	}



	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
		
		
		
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);;
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);;
	}

	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getSexMale() {
		return sexMale;
	}

	public void setSexMale() {
		this.sexMale.click();
	}

	public WebElement getSexFemale() {
		return sexFemale;
	}

	public void setSexFemale() {
		this.sexFemale.click();
	}

	public WebElement getLanguage_English() {
		return language_English;
	}

	public void setLanguage_English() {
		this.language_English.click();
	}

	public WebElement getLanguage_NonEnglish() {
		return language_NonEnglish;
	}

	public void setLanguage_NonEnglish() {
		this.language_NonEnglish.click();
	}

	public WebElement getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();;
	}
}
	
	
	
	
	
	
	
	
	
	